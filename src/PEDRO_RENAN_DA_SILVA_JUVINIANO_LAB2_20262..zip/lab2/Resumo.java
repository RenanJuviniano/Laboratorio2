package lab2;

public class Resumo {
}
